public class Main {
    public static void main(String[] args) throws InterruptedException {
        String palavra;
        System.out.println("--Cifra de Nlongônia--\n");
        MenuParalelo.menu();

    }
}